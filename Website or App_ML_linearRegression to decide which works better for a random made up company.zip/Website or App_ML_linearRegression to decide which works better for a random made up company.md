

```python
# Python 3.7
# Analysing the data for usage of app and website for a perticular company
```


```python
# Usual imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
%matplotlib inline
```


```python
customers = pd.read_csv('Ecommerce Customers')
```


```python
# Check out the info() method
customers.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 500 entries, 0 to 499
    Data columns (total 8 columns):
    Email                   500 non-null object
    Address                 500 non-null object
    Avatar                  500 non-null object
    Avg. Session Length     500 non-null float64
    Time on App             500 non-null float64
    Time on Website         500 non-null float64
    Length of Membership    500 non-null float64
    Yearly Amount Spent     500 non-null float64
    dtypes: float64(5), object(3)
    memory usage: 31.3+ KB
    


```python
# Let's replace the 'space' in the column names with an 'underscore'
customers.columns = customers.columns.str.replace(' ','_')
```


```python
# One way to get the columns which are only float or int type are is to use describe() method
customers.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Avg._Session_Length</th>
      <th>Time_on_App</th>
      <th>Time_on_Website</th>
      <th>Length_of_Membership</th>
      <th>Yearly_Amount_Spent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
      <td>500.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>33.053194</td>
      <td>12.052488</td>
      <td>37.060445</td>
      <td>3.533462</td>
      <td>499.314038</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.992563</td>
      <td>0.994216</td>
      <td>1.010489</td>
      <td>0.999278</td>
      <td>79.314782</td>
    </tr>
    <tr>
      <th>min</th>
      <td>29.532429</td>
      <td>8.508152</td>
      <td>33.913847</td>
      <td>0.269901</td>
      <td>256.670582</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>32.341822</td>
      <td>11.388153</td>
      <td>36.349257</td>
      <td>2.930450</td>
      <td>445.038277</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>33.082008</td>
      <td>11.983231</td>
      <td>37.069367</td>
      <td>3.533975</td>
      <td>498.887875</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>33.711985</td>
      <td>12.753850</td>
      <td>37.716432</td>
      <td>4.126502</td>
      <td>549.313828</td>
    </tr>
    <tr>
      <th>max</th>
      <td>36.139662</td>
      <td>15.126994</td>
      <td>40.005182</td>
      <td>6.922689</td>
      <td>765.518462</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Use the column list from the dataframe derived out of describe() method 
customers.describe().columns
```




    Index(['Avg._Session_Length', 'Time_on_App', 'Time_on_Website',
           'Length_of_Membership', 'Yearly_Amount_Spent'],
          dtype='object')




```python
# Settings for a format in Seaborn
sns.set_palette("GnBu_d")
sns.set_style('whitegrid')
```


```python
# Let's make a jointplot to visualize the correlation between 'Time on Website' 
sns.jointplot(data=customers, x='Time_on_Website',y='Yearly_Amount_Spent',kind='hex' )
```




    <seaborn.axisgrid.JointGrid at 0x230a81ff358>




![png](output_9_1.png)



```python
# Let's make a jointplot between 'Time_on_App' and 'Yearly_Amount_Spent'
sns.jointplot(data=customers, x='Time_on_App', y='Yearly_Amount_Spent', kind='hex',)
```




    <seaborn.axisgrid.JointGrid at 0x230a857b438>




![png](output_10_1.png)



```python
sns.pairplot(data=customers)
```




    <seaborn.axisgrid.PairGrid at 0x230a878ea90>




![png](output_11_1.png)



```python
# From the above plot, clearly the length_of_membership is linearly correlated to 'Yearly_amount_Spent'
# Let's explore this a bit
# Use seaborns linear model plot method (lmplot()) to correlate these two columns
sns.lmplot(data=customers, x='Length_of_Membership', y='Yearly_Amount_Spent')
```




    <seaborn.axisgrid.FacetGrid at 0x230a90b0128>




![png](output_12_1.png)


### ML


```python
# Let's get 'Yearly_Amount_Spent' as the target 
y = customers['Yearly_Amount_Spent']
# Let's get other columns as variables affecting the target
X = customers[['Avg._Session_Length', 'Time_on_App', 'Time_on_Website',
       'Length_of_Membership']]
```


```python
from sklearn.model_selection import train_test_split
```


```python
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=101)
```


```python
# Step to train the model on our data
from sklearn.linear_model import LinearRegression
# Instantiate the model
lm = LinearRegression()
# Train the model
lm.fit(X_train, y_train)
```




    LinearRegression(copy_X=True, fit_intercept=True, n_jobs=None, normalize=False)




```python
# Print out the coefficients of the model
print('The intercept is: ', lm.intercept_)
print('The set of co-efficients is: ', lm.coef_)
```

    The intercept is:  -1047.9327822502387
    The set of co-efficients is:  [25.98154972 38.59015875  0.19040528 61.27909654]
    

### Predicting the test data


```python
pred_values = lm.predict(X_test)
```


```python
# Analysing the accuracy of the model
# method # 1
pred_ratio = pred_values/y_test
sns.scatterplot(x=y_test, y=pred_ratio)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x230ab1588d0>




![png](output_21_1.png)



```python
# Analysing the accuracy of the model
# method # 2
sns.scatterplot(x=y_test, y=pred_values)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x230ab1bc5c0>




![png](output_22_1.png)


### Evaluating the model


```python
from sklearn import metrics

print('Mean Absolute Error(MAE): ', metrics.mean_absolute_error(y_test, pred_values))
print('Mean Squared Error(MAE): ', metrics.mean_squared_error(y_test, pred_values))
print('Root Mean Squared Error(MAE): ', np.sqrt(metrics.mean_squared_error(y_test, pred_values)))
```

    Mean Absolute Error(MAE):  7.228148653430853
    Mean Squared Error(MAE):  79.81305165097487
    Root Mean Squared Error(MAE):  8.933815066978656
    

### Residuals


```python
sns.distplot(pred_values, bins=50)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x230ab225128>




![png](output_26_1.png)



```python
plt.hist(pred_values, bins=50)
```




    (array([ 1.,  0.,  0.,  0.,  0.,  1.,  0.,  1.,  2.,  2.,  1.,  3.,  3.,
             1.,  3.,  6.,  6.,  3.,  6.,  9.,  5.,  7.,  5.,  6.,  9.,  6.,
             7.,  7., 10., 10.,  4.,  8.,  4.,  3.,  1.,  2.,  0.,  2.,  0.,
             0.,  1.,  0.,  1.,  1.,  0.,  1.,  0.,  0.,  1.,  1.]),
     array([256.28674001, 266.47152336, 276.65630671, 286.84109006,
            297.02587341, 307.21065676, 317.39544011, 327.58022346,
            337.76500682, 347.94979017, 358.13457352, 368.31935687,
            378.50414022, 388.68892357, 398.87370692, 409.05849027,
            419.24327362, 429.42805697, 439.61284032, 449.79762367,
            459.98240702, 470.16719037, 480.35197372, 490.53675707,
            500.72154042, 510.90632377, 521.09110712, 531.27589048,
            541.46067383, 551.64545718, 561.83024053, 572.01502388,
            582.19980723, 592.38459058, 602.56937393, 612.75415728,
            622.93894063, 633.12372398, 643.30850733, 653.49329068,
            663.67807403, 673.86285738, 684.04764073, 694.23242408,
            704.41720743, 714.60199078, 724.78677414, 734.97155749,
            745.15634084, 755.34112419, 765.52590754]),
     <a list of 50 Patch objects>)




![png](output_27_1.png)

